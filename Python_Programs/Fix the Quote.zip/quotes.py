# TODO: Fix this string!
ford_quote = 'Whether you think you can, or you think you can't--you're right.'