# This is my vowel counting code:

vowel_count += prophecy.count('a')
vowel_count += prophecy.count('A')
vowel_count += prophecy.count('e')
vowel_count += prophecy.count('E')
vowel_count += prophecy.count('i')
vowel_count += prophecy.count('I')
vowel_count += prophecy.count('o')
vowel_count += prophecy.count('O')
vowel_count += prophecy.count('u')
vowel_count += prophecy.count('U')

'''
Looking at this first attempt, I think I can make it better. Counting 
both lower-case 'a' and upper-case 'A', seems unnecessary. I'll convert 
everything to lower-case, and then I only need to count each vowel once!
'''

vowel_count = 0
lower_prophecy = prophecy.lower()
vowel_count += lower_prophecy.count('a')
vowel_count += lower_prophecy.count('e')
vowel_count += lower_prophecy.count('i')
vowel_count += lower_prophecy.count('o')
vowel_count += lower_prophecy.count('u')
print(vowel_count)

'''
It's easy to check that I got the same result with my new, shorter version. 
There was nothing especially wrong with the first version, but it was only 
after I had written my first idea that I realised the efficiency I could make
in the second attempt. Getting started with a simple idea and then improving 
my work from there is a common pattern I use when programming, I recommend 
you try it too.
'''