given_name = "Charlotte"
middle_names = "Hippopotamus"
family_name = "Turner"

name_length = #todo: calculate how long this name is

driving_licence_character_limit = 28
print(name_length <= driving_licence_character_limit)