#browse the complete list of string methods at https://docs.python.org/3/library/stdtypes.html#string-methods
#and try them out here